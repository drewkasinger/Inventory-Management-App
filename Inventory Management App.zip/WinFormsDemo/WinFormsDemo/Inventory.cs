﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsDemo
{
    public class Inventory
    {
        public static BindingList<Product> Products { get; set; } = new BindingList<Product>();
        public static BindingList<Part> AllParts { get; set; } = new BindingList<Part>();

        public static void addProduct(Product product)
        {
            Products.Add(product);
        }
        public static bool removeProduct(int id)
        {
            Product deleteProduct = lookupProduct(id);
            if (deleteProduct != null)
            {
                Products.Remove(deleteProduct);
                return true;
            }
            return false;
        }
        public static Product lookupProduct(int id)
        {
            foreach (Product product in Products)
            {
                if (id == product.ProductID)
                {
                    return product;
                }
            }
            return null;
        }
        public static void updateProduct(int id, Product product)
        {
            int indexNumber = ProductIndexFinder(id);
            Products.RemoveAt(indexNumber);
            addProduct(product);
        }



        
        public static void addPart(Part part)
        {
            AllParts.Add(part);
        }
        public static bool deletePart(Part part)
        {
            if (!AllParts.Contains(part))
            {
                return false;
            }
                AllParts.Remove(part);
                return true;
        }
        public static Part lookupPart(int id)
        {
            foreach (Part part in AllParts)
            {
                if (id == part.PartID)
                {
                    return part;
                }
            }
            return null;
        }

        public static void updatePart(int id, Part part)
        {
            int indexNumber = PartIndexFinder(id);
            AllParts.RemoveAt(indexNumber);
            addPart(part);
        }


       
        

        public static int GenerateID()
        {
            Random rnd = new Random();
            int inventoryLimit = rnd.Next(1, 1000);
            return inventoryLimit;
        }

        public static int PartIndexFinder(int id)
        {
            foreach (Part checkPart in AllParts)
            {
                if (id == checkPart.PartID)
                {
                    int indexNumber = AllParts.IndexOf(checkPart);
                    return indexNumber;
                }
            }
            return -1;
        }

        public static int ProductIndexFinder(int id)
        {
            foreach (Product checkProduct in Products)
            {
                if (id == checkProduct.ProductID)
                {
                    int indexNumber = Products.IndexOf(checkProduct);
                    return indexNumber;
                }
            }
            return -1;
        }
    }
}
﻿namespace WinFormsDemo
{
    partial class AddPartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addPartOutsourcedRadio = new RadioButton();
            addPartInHouseRadio = new RadioButton();
            addPartTempLabel = new Label();
            addPartMax = new Label();
            addPartMin = new Label();
            addPartInStock = new Label();
            addPartName = new Label();
            addPartLabel = new Label();
            addPartPrice = new Label();
            addPartID = new Label();
            addPartIDTextBox = new TextBox();
            addPartNameTextBox = new TextBox();
            addPartPriceTextBox = new TextBox();
            addPartInStockTextBox = new TextBox();
            addPartMinTextBox = new TextBox();
            addPartMaxTextBox = new TextBox();
            addPartTempTextBox = new TextBox();
            addPartSaveButton = new Button();
            addPartCancelButton = new Button();
            SuspendLayout();
            // 
            // addPartOutsourcedRadio
            // 
            addPartOutsourcedRadio.AutoSize = true;
            addPartOutsourcedRadio.Location = new Point(413, 15);
            addPartOutsourcedRadio.Name = "addPartOutsourcedRadio";
            addPartOutsourcedRadio.Size = new Size(87, 19);
            addPartOutsourcedRadio.TabIndex = 19;
            addPartOutsourcedRadio.Text = "Outsourced";
            addPartOutsourcedRadio.UseVisualStyleBackColor = true;
            addPartOutsourcedRadio.CheckedChanged += addPartOutsourced_CheckedChanged;
            // 
            // addPartInHouseRadio
            // 
            addPartInHouseRadio.AutoSize = true;
            addPartInHouseRadio.Location = new Point(228, 15);
            addPartInHouseRadio.Name = "addPartInHouseRadio";
            addPartInHouseRadio.Size = new Size(74, 19);
            addPartInHouseRadio.TabIndex = 18;
            addPartInHouseRadio.Text = "In-House";
            addPartInHouseRadio.UseVisualStyleBackColor = true;
            addPartInHouseRadio.CheckedChanged += addPartInHouse_CheckedChanged;
            // 
            // addPartTempLabel
            // 
            addPartTempLabel.AutoSize = true;
            addPartTempLabel.Location = new Point(210, 397);
            addPartTempLabel.Name = "addPartTempLabel";
            addPartTempLabel.Size = new Size(67, 15);
            addPartTempLabel.TabIndex = 17;
            addPartTempLabel.Text = "Machine ID";
            // 
            // addPartMax
            // 
            addPartMax.AutoSize = true;
            addPartMax.Location = new Point(210, 347);
            addPartMax.Name = "addPartMax";
            addPartMax.Size = new Size(29, 15);
            addPartMax.TabIndex = 16;
            addPartMax.Text = "Max";
            // 
            // addPartMin
            // 
            addPartMin.AutoSize = true;
            addPartMin.Location = new Point(210, 297);
            addPartMin.Name = "addPartMin";
            addPartMin.Size = new Size(28, 15);
            addPartMin.TabIndex = 15;
            addPartMin.Text = "Min";
            // 
            // addPartInStock
            // 
            addPartInStock.AutoSize = true;
            addPartInStock.Location = new Point(210, 247);
            addPartInStock.Name = "addPartInStock";
            addPartInStock.Size = new Size(46, 15);
            addPartInStock.TabIndex = 14;
            addPartInStock.Text = "InStock";
            // 
            // addPartName
            // 
            addPartName.AutoSize = true;
            addPartName.Location = new Point(210, 147);
            addPartName.Name = "addPartName";
            addPartName.Size = new Size(39, 15);
            addPartName.TabIndex = 12;
            addPartName.Text = "Name";
            // 
            // addPartLabel
            // 
            addPartLabel.AutoSize = true;
            addPartLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addPartLabel.Location = new Point(12, 9);
            addPartLabel.Name = "addPartLabel";
            addPartLabel.Size = new Size(84, 25);
            addPartLabel.TabIndex = 10;
            addPartLabel.Text = "Add Part";
            // 
            // addPartPrice
            // 
            addPartPrice.AutoSize = true;
            addPartPrice.Location = new Point(210, 197);
            addPartPrice.Name = "addPartPrice";
            addPartPrice.Size = new Size(33, 15);
            addPartPrice.TabIndex = 13;
            addPartPrice.Text = "Price";
            // 
            // addPartID
            // 
            addPartID.AutoSize = true;
            addPartID.Location = new Point(210, 97);
            addPartID.Name = "addPartID";
            addPartID.Size = new Size(42, 15);
            addPartID.TabIndex = 11;
            addPartID.Text = "Part ID";
            addPartID.TextAlign = ContentAlignment.TopRight;
            // 
            // addPartIDTextBox
            // 
            addPartIDTextBox.Enabled = false;
            addPartIDTextBox.Location = new Point(299, 94);
            addPartIDTextBox.Name = "addPartIDTextBox";
            addPartIDTextBox.Size = new Size(221, 23);
            addPartIDTextBox.TabIndex = 20;
            // 
            // addPartNameTextBox
            // 
            addPartNameTextBox.Location = new Point(299, 144);
            addPartNameTextBox.Name = "addPartNameTextBox";
            addPartNameTextBox.Size = new Size(221, 23);
            addPartNameTextBox.TabIndex = 22;
            // 
            // addPartPriceTextBox
            // 
            addPartPriceTextBox.Location = new Point(299, 194);
            addPartPriceTextBox.Name = "addPartPriceTextBox";
            addPartPriceTextBox.Size = new Size(221, 23);
            addPartPriceTextBox.TabIndex = 23;
            // 
            // addPartInStockTextBox
            // 
            addPartInStockTextBox.Location = new Point(299, 244);
            addPartInStockTextBox.Name = "addPartInStockTextBox";
            addPartInStockTextBox.Size = new Size(221, 23);
            addPartInStockTextBox.TabIndex = 24;
            // 
            // addPartMinTextBox
            // 
            addPartMinTextBox.Location = new Point(299, 294);
            addPartMinTextBox.Name = "addPartMinTextBox";
            addPartMinTextBox.Size = new Size(221, 23);
            addPartMinTextBox.TabIndex = 25;
            // 
            // addPartMaxTextBox
            // 
            addPartMaxTextBox.Location = new Point(299, 344);
            addPartMaxTextBox.Name = "addPartMaxTextBox";
            addPartMaxTextBox.Size = new Size(221, 23);
            addPartMaxTextBox.TabIndex = 26;
            // 
            // addPartTempTextBox
            // 
            addPartTempTextBox.Location = new Point(299, 394);
            addPartTempTextBox.Name = "addPartTempTextBox";
            addPartTempTextBox.Size = new Size(221, 23);
            addPartTempTextBox.TabIndex = 27;
            // 
            // addPartSaveButton
            // 
            addPartSaveButton.Location = new Point(228, 468);
            addPartSaveButton.Name = "addPartSaveButton";
            addPartSaveButton.Size = new Size(107, 47);
            addPartSaveButton.TabIndex = 28;
            addPartSaveButton.Text = "Save";
            addPartSaveButton.UseVisualStyleBackColor = true;
            addPartSaveButton.Click += addPartSaveButton_Click;
            // 
            // addPartCancelButton
            // 
            addPartCancelButton.Location = new Point(413, 468);
            addPartCancelButton.Name = "addPartCancelButton";
            addPartCancelButton.Size = new Size(107, 47);
            addPartCancelButton.TabIndex = 29;
            addPartCancelButton.Text = "Cancel";
            addPartCancelButton.UseVisualStyleBackColor = true;
            addPartCancelButton.Click += addPartCancelButton_Click;
            // 
            // AddPartForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(756, 527);
            Controls.Add(addPartCancelButton);
            Controls.Add(addPartSaveButton);
            Controls.Add(addPartTempTextBox);
            Controls.Add(addPartMaxTextBox);
            Controls.Add(addPartMinTextBox);
            Controls.Add(addPartInStockTextBox);
            Controls.Add(addPartPriceTextBox);
            Controls.Add(addPartNameTextBox);
            Controls.Add(addPartIDTextBox);
            Controls.Add(addPartOutsourcedRadio);
            Controls.Add(addPartInHouseRadio);
            Controls.Add(addPartTempLabel);
            Controls.Add(addPartMax);
            Controls.Add(addPartMin);
            Controls.Add(addPartInStock);
            Controls.Add(addPartName);
            Controls.Add(addPartLabel);
            Controls.Add(addPartPrice);
            Controls.Add(addPartID);
            Name = "AddPartForm";
            Text = "Add Parts Form";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton addPartOutsourcedRadio;
        private RadioButton addPartInHouseRadio;
        private Label addPartTempLabel;
        private Label addPartMax;
        private Label addPartMin;
        private Label addPartInStock;
        private Label addPartName;
        private Label addPartLabel;
        private Label addPartPrice;
        private Label addPartID;
        private TextBox addPartIDTextBox;
        private TextBox addPartNameTextBox;
        private TextBox addPartPriceTextBox;
        private TextBox addPartInStockTextBox;
        private TextBox addPartMinTextBox;
        private TextBox addPartMaxTextBox;
        private TextBox addPartTempTextBox;
        private Button addPartSaveButton;
        private Button addPartCancelButton;
    }
}
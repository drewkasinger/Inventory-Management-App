﻿namespace WinFormsDemo
{
    partial class ModifyPartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            modifyPartCancelButton = new Button();
            modifyPartSaveButton = new Button();
            modifyPartOutsourcedRadio = new RadioButton();
            modifyPartInHouseRadio = new RadioButton();
            modifyPartTempLabel = new Label();
            modifyPartMax = new Label();
            modifyPartMin = new Label();
            modifyPartInStock = new Label();
            modifyPartName = new Label();
            modifyPartLabel = new Label();
            modifyPartPrice = new Label();
            modifyPartID = new Label();
            modifyPartTempTextBox = new TextBox();
            modifyPartMaxTextBox = new TextBox();
            modifyPartMinTextBox = new TextBox();
            modifyPartInStockTextBox = new TextBox();
            modifyPartPriceTextBox = new TextBox();
            modifyPartNameTextBox = new TextBox();
            modifyPartIDTextBox = new TextBox();
            SuspendLayout();
            // 
            // modifyPartCancelButton
            // 
            modifyPartCancelButton.Location = new Point(413, 468);
            modifyPartCancelButton.Name = "modifyPartCancelButton";
            modifyPartCancelButton.Size = new Size(107, 47);
            modifyPartCancelButton.TabIndex = 48;
            modifyPartCancelButton.Text = "Cancel";
            modifyPartCancelButton.UseVisualStyleBackColor = true;
            modifyPartCancelButton.Click += modifyPartCancelButton_Click;
            // 
            // modifyPartSaveButton
            // 
            modifyPartSaveButton.Location = new Point(228, 468);
            modifyPartSaveButton.Name = "modifyPartSaveButton";
            modifyPartSaveButton.Size = new Size(107, 47);
            modifyPartSaveButton.TabIndex = 47;
            modifyPartSaveButton.Text = "Save";
            modifyPartSaveButton.UseVisualStyleBackColor = true;
            modifyPartSaveButton.Click += modifyPartSaveButton_Click;
            // 
            // modifyPartOutsourcedRadio
            // 
            modifyPartOutsourcedRadio.AutoSize = true;
            modifyPartOutsourcedRadio.Location = new Point(413, 15);
            modifyPartOutsourcedRadio.Name = "modifyPartOutsourcedRadio";
            modifyPartOutsourcedRadio.Size = new Size(87, 19);
            modifyPartOutsourcedRadio.TabIndex = 39;
            modifyPartOutsourcedRadio.Text = "Outsourced";
            modifyPartOutsourcedRadio.UseVisualStyleBackColor = true;
            modifyPartOutsourcedRadio.CheckedChanged += modifyPartOutsourcedRadio_CheckedChanged;
            // 
            // modifyPartInHouseRadio
            // 
            modifyPartInHouseRadio.AutoSize = true;
            modifyPartInHouseRadio.Location = new Point(228, 15);
            modifyPartInHouseRadio.Name = "modifyPartInHouseRadio";
            modifyPartInHouseRadio.Size = new Size(74, 19);
            modifyPartInHouseRadio.TabIndex = 38;
            modifyPartInHouseRadio.Text = "In-House";
            modifyPartInHouseRadio.UseVisualStyleBackColor = true;
            modifyPartInHouseRadio.CheckedChanged += modifyPartInHouseRadio_CheckedChanged;
            // 
            // modifyPartTempLabel
            // 
            modifyPartTempLabel.AutoSize = true;
            modifyPartTempLabel.Location = new Point(207, 397);
            modifyPartTempLabel.Name = "modifyPartTempLabel";
            modifyPartTempLabel.Size = new Size(35, 15);
            modifyPartTempLabel.TabIndex = 37;
            modifyPartTempLabel.Text = "temp";
            // 
            // modifyPartMax
            // 
            modifyPartMax.AutoSize = true;
            modifyPartMax.Location = new Point(207, 347);
            modifyPartMax.Name = "modifyPartMax";
            modifyPartMax.Size = new Size(29, 15);
            modifyPartMax.TabIndex = 36;
            modifyPartMax.Text = "Max";
            // 
            // modifyPartMin
            // 
            modifyPartMin.AutoSize = true;
            modifyPartMin.Location = new Point(207, 297);
            modifyPartMin.Name = "modifyPartMin";
            modifyPartMin.Size = new Size(28, 15);
            modifyPartMin.TabIndex = 35;
            modifyPartMin.Text = "Min";
            // 
            // modifyPartInStock
            // 
            modifyPartInStock.AutoSize = true;
            modifyPartInStock.Location = new Point(207, 247);
            modifyPartInStock.Name = "modifyPartInStock";
            modifyPartInStock.Size = new Size(46, 15);
            modifyPartInStock.TabIndex = 34;
            modifyPartInStock.Text = "InStock";
            // 
            // modifyPartName
            // 
            modifyPartName.AutoSize = true;
            modifyPartName.Location = new Point(207, 147);
            modifyPartName.Name = "modifyPartName";
            modifyPartName.Size = new Size(39, 15);
            modifyPartName.TabIndex = 32;
            modifyPartName.Text = "Name";
            // 
            // modifyPartLabel
            // 
            modifyPartLabel.AutoSize = true;
            modifyPartLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            modifyPartLabel.Location = new Point(12, 9);
            modifyPartLabel.Name = "modifyPartLabel";
            modifyPartLabel.Size = new Size(109, 25);
            modifyPartLabel.TabIndex = 30;
            modifyPartLabel.Text = "Modify Part";
            // 
            // modifyPartPrice
            // 
            modifyPartPrice.AutoSize = true;
            modifyPartPrice.Location = new Point(207, 197);
            modifyPartPrice.Name = "modifyPartPrice";
            modifyPartPrice.Size = new Size(33, 15);
            modifyPartPrice.TabIndex = 33;
            modifyPartPrice.Text = "Price";
            // 
            // modifyPartID
            // 
            modifyPartID.AutoSize = true;
            modifyPartID.Location = new Point(207, 97);
            modifyPartID.Name = "modifyPartID";
            modifyPartID.Size = new Size(42, 15);
            modifyPartID.TabIndex = 31;
            modifyPartID.Text = "Part ID";
            modifyPartID.TextAlign = ContentAlignment.TopRight;
            // 
            // modifyPartTempTextBox
            // 
            modifyPartTempTextBox.Location = new Point(279, 394);
            modifyPartTempTextBox.Name = "modifyPartTempTextBox";
            modifyPartTempTextBox.Size = new Size(221, 23);
            modifyPartTempTextBox.TabIndex = 55;
            // 
            // modifyPartMaxTextBox
            // 
            modifyPartMaxTextBox.Location = new Point(279, 344);
            modifyPartMaxTextBox.Name = "modifyPartMaxTextBox";
            modifyPartMaxTextBox.Size = new Size(221, 23);
            modifyPartMaxTextBox.TabIndex = 54;
            // 
            // modifyPartMinTextBox
            // 
            modifyPartMinTextBox.Location = new Point(279, 294);
            modifyPartMinTextBox.Name = "modifyPartMinTextBox";
            modifyPartMinTextBox.Size = new Size(221, 23);
            modifyPartMinTextBox.TabIndex = 53;
            // 
            // modifyPartInStockTextBox
            // 
            modifyPartInStockTextBox.Location = new Point(279, 244);
            modifyPartInStockTextBox.Name = "modifyPartInStockTextBox";
            modifyPartInStockTextBox.Size = new Size(221, 23);
            modifyPartInStockTextBox.TabIndex = 52;
            // 
            // modifyPartPriceTextBox
            // 
            modifyPartPriceTextBox.Location = new Point(279, 194);
            modifyPartPriceTextBox.Name = "modifyPartPriceTextBox";
            modifyPartPriceTextBox.Size = new Size(221, 23);
            modifyPartPriceTextBox.TabIndex = 51;
            // 
            // modifyPartNameTextBox
            // 
            modifyPartNameTextBox.Location = new Point(279, 144);
            modifyPartNameTextBox.Name = "modifyPartNameTextBox";
            modifyPartNameTextBox.Size = new Size(221, 23);
            modifyPartNameTextBox.TabIndex = 50;
            // 
            // modifyPartIDTextBox
            // 
            modifyPartIDTextBox.Enabled = false;
            modifyPartIDTextBox.Location = new Point(279, 94);
            modifyPartIDTextBox.Name = "modifyPartIDTextBox";
            modifyPartIDTextBox.Size = new Size(221, 23);
            modifyPartIDTextBox.TabIndex = 49;
            // 
            // ModifyPartForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(756, 528);
            Controls.Add(modifyPartTempTextBox);
            Controls.Add(modifyPartMaxTextBox);
            Controls.Add(modifyPartMinTextBox);
            Controls.Add(modifyPartInStockTextBox);
            Controls.Add(modifyPartPriceTextBox);
            Controls.Add(modifyPartNameTextBox);
            Controls.Add(modifyPartIDTextBox);
            Controls.Add(modifyPartCancelButton);
            Controls.Add(modifyPartSaveButton);
            Controls.Add(modifyPartOutsourcedRadio);
            Controls.Add(modifyPartInHouseRadio);
            Controls.Add(modifyPartTempLabel);
            Controls.Add(modifyPartMax);
            Controls.Add(modifyPartMin);
            Controls.Add(modifyPartInStock);
            Controls.Add(modifyPartName);
            Controls.Add(modifyPartLabel);
            Controls.Add(modifyPartPrice);
            Controls.Add(modifyPartID);
            Name = "ModifyPartForm";
            Text = "Modify Parts Form";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button modifyPartCancelButton;
        private Button modifyPartSaveButton;
        private RadioButton modifyPartOutsourcedRadio;
        private RadioButton modifyPartInHouseRadio;
        private Label modifyPartTempLabel;
        private Label modifyPartMax;
        private Label modifyPartMin;
        private Label modifyPartInStock;
        private Label modifyPartName;
        private Label modifyPartLabel;
        private Label modifyPartPrice;
        private Label modifyPartID;
        private TextBox modifyPartTempTextBox;
        private TextBox modifyPartMaxTextBox;
        private TextBox modifyPartMinTextBox;
        private TextBox modifyPartInStockTextBox;
        private TextBox modifyPartPriceTextBox;
        private TextBox modifyPartNameTextBox;
        private TextBox modifyPartIDTextBox;
    }
}
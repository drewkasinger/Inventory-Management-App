﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsDemo
{
    public partial class AddProductForm : Form
    {

        //create instance
        Product myproduct = new Product();
        public AddProductForm()
        {
            InitializeComponent();
        }

        private void AddProductForm_Load(object sender, EventArgs e)
        {

            addProductsCandidatePartsDataGridView.DataSource = Inventory.AllParts;
            addProductsAssociatedPartsDataGridView.DataSource = myproduct.AssociatedParts;
        }
        private void AddProductForm_Activated(object sender, EventArgs e)
        {
            addProductsCandidatePartsDataGridView.ClearSelection();
            addProductsAssociatedPartsDataGridView.ClearSelection();
        }

        private void addProductSaveButton_Click(object sender, EventArgs e)
        {
            if (
                string.IsNullOrEmpty(addProductNameTextBox.Text))
                MessageBox.Show("Please enter infomation for Name");
            else if (producttextbox() != null)
            {
                MessageBox.Show(producttextbox());
                return;
            }
            else if (minmaxvalidation() != null)
            {
                MessageBox.Show(minmaxvalidation());
                return;
            }
            else
            {
                Product newProduct = new Product
                {
                    ProductID = Inventory.GenerateID(),
                    Name = addProductNameTextBox.Text,
                    Price = decimal.Parse(addProductPriceTextBox.Text),
                    InStock = int.Parse(addProductInStockTextBox.Text),
                    Min = int.Parse(addProductMinTextBox.Text),
                    Max = int.Parse(addProductMaxTextBox.Text),
                };

                foreach (DataGridViewRow row in addProductsAssociatedPartsDataGridView.Rows)
                {
                    Part part = (Part)row.DataBoundItem;
                    newProduct.AssociatedParts.Add(part);
                }

                //add to associated list, foreach loop through each row, cast each row as a part. newproduct.associatedparts.add casted parts
                Inventory.addProduct(newProduct);
                this.Close();
            }
        }

        private void addProductCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addProductAddButton_Click(object sender, EventArgs e)
        {
            myproduct.AssociatedParts.Add((Part)addProductsCandidatePartsDataGridView.CurrentRow.DataBoundItem);
            addProductsCandidatePartsDataGridView.ClearSelection();
            addProductsAssociatedPartsDataGridView.ClearSelection();
        }

        private void addProductDeleteButton_Click(object sender, EventArgs e)
        {
            //this stops program from throwing an error when nothing is in the list
            if (addProductsAssociatedPartsDataGridView.CurrentRow == null)
            {
                MessageBox.Show("There is nothing to delete.");
                return;
            }
            if (!addProductsAssociatedPartsDataGridView.CurrentRow.Selected)
            {
                MessageBox.Show("Nothing Selected, Please Make a Selection");
                return;
            }
            if (MessageBox.Show("Are you sure you want to delete this product?", "Delete Product?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int rowIndex = addProductsAssociatedPartsDataGridView.CurrentCell.RowIndex;
                myproduct.AssociatedParts.RemoveAt(rowIndex);
            }
        }

        private void addProductCandidatePartsSearchButton_Click(object sender, EventArgs e)
        {
            addProductsCandidatePartsDataGridView.ClearSelection();
            try
            {
                var locatePart = Inventory.lookupPart(int.Parse(addProductCandidatePartsSearchTextBox.Text));
                if (locatePart == null)
                {
                    MessageBox.Show("No Part Found.");
                }
                string partIDValue = addProductCandidatePartsSearchTextBox.Text;
                int rowIndex;
                foreach (DataGridViewRow row in addProductsCandidatePartsDataGridView.Rows)
                {
                    if (row.Cells[0].Value.ToString() == partIDValue)
                    {
                        rowIndex = row.Cells[0].RowIndex;
                        addProductsCandidatePartsDataGridView.Rows[rowIndex].Selected = true;
                        break;
                    }
                }
            }
            catch { return; }
        }

        private void addProductAssociatedPartsSearchButton_Click(object sender, EventArgs e)
        {
            addProductsAssociatedPartsDataGridView.ClearSelection();
            try
            {
                var locatePart = Inventory.lookupPart(int.Parse(addProductAssociatedPartsSearchTextBox.Text));
                if (locatePart == null)
                {
                    MessageBox.Show("No Part Found.");
                }
                string productIDValue = addProductAssociatedPartsSearchTextBox.Text;
                int rowIndex;
                foreach (DataGridViewRow row in addProductsAssociatedPartsDataGridView.Rows)
                {
                    if (row.Cells[0].Value.ToString() == productIDValue)
                    {
                        rowIndex = row.Cells[0].RowIndex;
                        addProductsAssociatedPartsDataGridView.Rows[rowIndex].Selected = true;
                        break;
                    }
                }
            }
            catch { return; }
        }

        public string producttextbox()
        {
            int price;
            bool pricetextbox = int.TryParse(addProductPriceTextBox.Text, out price);
            if (!pricetextbox)
            {
                return "Price must be a number";
            }

            int instock;
            bool instocktextbox = int.TryParse(addProductInStockTextBox.Text, out instock);
            if (!instocktextbox)
            {
                return "InStock must be a number";
            }

            int min;
            bool mintextbox = int.TryParse(addProductMinTextBox.Text, out min);
            if (!mintextbox)
            {
                return "Min must be a number";
            }

            int max;
            bool maxtempbox = int.TryParse(addProductMaxTextBox.Text, out max);
            if (!maxtempbox)
            {
                return "Max must be a number";
            }
            return null;
        }

        public string minmaxvalidation()
        {
            if (int.Parse(addProductMinTextBox.Text) > int.Parse(addProductMaxTextBox.Text))
            {
                return "Min must be less then or equal to Max.";
            }
            if (int.Parse(addProductInStockTextBox.Text) < int.Parse(addProductMinTextBox.Text))
            {
                return "InStock must be larger then Min.";
            }
            if (int.Parse(addProductInStockTextBox.Text) > int.Parse(addProductMaxTextBox.Text))
            {
                return "InStock must be Smaller then Max.";
            }
            return null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsDemo
{
    public class Inhouse : Part
    {
        public int MachineID { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsDemo
{
    public partial class AddPartForm : Form
    {
        string radioChecker = "";
        public AddPartForm()
        {
            InitializeComponent();
        }



        public void addPartSaveButton_Click(object sender, EventArgs e)
        {
            if (radioChecker == "In-House")
            {
                inhouseValidation();
            }
            else if (radioChecker == "Outsourced")
            {
                outsourcedValidation();
            }
            else
            {
                MessageBox.Show("Please select In-House or Outsourced");
            }
        }

        private void addPartCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addPartInHouse_CheckedChanged(object sender, EventArgs e)
        {
            if (addPartInHouseRadio.Checked)
            {
                radioChecker = "In-House";
                addPartTempLabel.Text = "Machine ID";
            }
        }

        private void addPartOutsourced_CheckedChanged(object sender, EventArgs e)
        {
            if (addPartOutsourcedRadio.Checked)
            {
                radioChecker = "Outsourced";
                addPartTempLabel.Text = "Company Name";
            }
        }

        public void inhouseValidation()
        {
            if (
                string.IsNullOrEmpty(addPartNameTextBox.Text))
                MessageBox.Show("Please enter infomation for Name");
            else if (inhousetextbox() != null)
            {
                MessageBox.Show(inhousetextbox());
                return;
            }
            else if (minmaxvalidation() != null)
            {
                MessageBox.Show(minmaxvalidation());
                return;
            }
            else
            {
                newInHousePart();
            }


        }
        public void outsourcedValidation()
        {
            if (string.IsNullOrEmpty(addPartNameTextBox.Text))
                MessageBox.Show("Please enter infomation for Name");
            else if (outsourcedtextbox() != null)
            {
                MessageBox.Show(outsourcedtextbox());
                return;
            }
            else if (string.IsNullOrEmpty(addPartTempTextBox.Text))
                MessageBox.Show("Please enter infomation for Company Name");
            else if (minmaxvalidation() != null)
            {
                MessageBox.Show(minmaxvalidation());
                return;
            }
            else
            {
                newOutsourcedPart();
            }
        }

        public void newInHousePart()
        {
            Part newPart = new Inhouse
            {
                PartID = Inventory.GenerateID(),
                Name = addPartNameTextBox.Text,
                Price = decimal.Parse(addPartPriceTextBox.Text),
                InStock = int.Parse(addPartInStockTextBox.Text),
                Min = int.Parse(addPartMinTextBox.Text),
                Max = int.Parse(addPartMaxTextBox.Text),
                MachineID = int.Parse(addPartTempTextBox.Text)
            };

            Inventory.addPart(newPart);
            this.Close();
        }
        public void newOutsourcedPart()
        {

            Part newPart = new Outsourced
            {
                PartID = Inventory.GenerateID(),
                Name = addPartNameTextBox.Text,
                Price = decimal.Parse(addPartPriceTextBox.Text),
                InStock = int.Parse(addPartInStockTextBox.Text),
                Min = int.Parse(addPartMinTextBox.Text),
                Max = int.Parse(addPartMaxTextBox.Text),
                CompanyName = addPartTempTextBox.Text
            };

            Inventory.AllParts.Add(newPart);
            this.Close();
        }

        public string inhousetextbox()
        {
            int price;
            bool pricetextbox = int.TryParse(addPartPriceTextBox.Text, out price);
            if (!pricetextbox)
            {
                return "Price must be a number";
            }

            int instock;
            bool instocktextbox = int.TryParse(addPartInStockTextBox.Text, out instock);
            if (!instocktextbox)
            {
                return "InStock must be a number";
            }

            int min;
            bool mintextbox = int.TryParse(addPartMinTextBox.Text, out min);
            if (!mintextbox)
            {
                return "Min must be a number";
            }

            int max;
            bool maxtempbox = int.TryParse(addPartMaxTextBox.Text, out max);
            if (!maxtempbox)
            {
                return "Max must be a number";
            }

            int temp;
            bool temptextbox = int.TryParse(addPartTempTextBox.Text, out temp);
            if (!temptextbox)
            {
                return "Machine ID must be a number";
            }
            return null;
        }
        public string outsourcedtextbox()
        {
            int price;
            bool pricetextbox = int.TryParse(addPartPriceTextBox.Text, out price);
            if (!pricetextbox)
            {
                return "Price must be a number";
            }

            int instock;
            bool instocktextbox = int.TryParse(addPartInStockTextBox.Text, out instock);
            if (!instocktextbox)
            {
                return "InStock must be a number";
            }

            int min;
            bool mintextbox = int.TryParse(addPartMinTextBox.Text, out min);
            if (!mintextbox)
            {
                return "Min must be a number";
            }

            int max;
            bool maxtempbox = int.TryParse(addPartMaxTextBox.Text, out max);
            if (!maxtempbox)
            {
                return "Max must be a number";
            }
            return null;
        }

        public string minmaxvalidation()
        {
            if (int.Parse(addPartMinTextBox.Text) > int.Parse(addPartMaxTextBox.Text))
            {
                return "Min must be less then or equal to Max.";
            }
            if (int.Parse(addPartInStockTextBox.Text) < int.Parse(addPartMinTextBox.Text))
            {
                return "InStock must be larger then Min.";
            }
            if (int.Parse(addPartInStockTextBox.Text) > int.Parse(addPartMaxTextBox.Text))
            {
                return "InStock must be Smaller then Max.";
            }
                return null;
        }
    }
}
﻿namespace WinFormsDemo
{
    partial class ModifyProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            modifyProductMaxLabel = new Label();
            modifyProductMinLabel = new Label();
            modifyProductInStockLabel = new Label();
            modifyProductNameLabel = new Label();
            modifyProductPriceLabel = new Label();
            modifyProductIDLabel = new Label();
            modifyProductCancelButton = new Button();
            modifyProductSaveButton = new Button();
            modifyProductDeleteButton = new Button();
            modifyProductAddButton = new Button();
            modifyProductsLabel = new Label();
            modifyProductAssociatedPartsSearchTextBox = new TextBox();
            modifyProductAssociatedPartsSearchButton = new Button();
            modifyProductsAssociatedPartsLabel = new Label();
            modifyProductsAssociatedPartsDataGridView = new DataGridView();
            modifyProductCandidatePartsSearchTextBox = new TextBox();
            modifyProductCandidatePartsSearchButton = new Button();
            modifyProductCandidatePartsLabel = new Label();
            modifyProductsCandidatePartsDataGridView = new DataGridView();
            modifyProductMaxTextBox = new TextBox();
            modifyProductMinTextBox = new TextBox();
            modifyProductInStockTextBox = new TextBox();
            modifyProductPriceTextBox = new TextBox();
            modifyProductNameTextBox = new TextBox();
            modifyProductIDTextBox = new TextBox();
            ((System.ComponentModel.ISupportInitialize)modifyProductsAssociatedPartsDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)modifyProductsCandidatePartsDataGridView).BeginInit();
            SuspendLayout();
            // 
            // modifyProductMaxLabel
            // 
            modifyProductMaxLabel.AutoSize = true;
            modifyProductMaxLabel.Location = new Point(120, 420);
            modifyProductMaxLabel.Name = "modifyProductMaxLabel";
            modifyProductMaxLabel.Size = new Size(29, 15);
            modifyProductMaxLabel.TabIndex = 68;
            modifyProductMaxLabel.Text = "Max";
            // 
            // modifyProductMinLabel
            // 
            modifyProductMinLabel.AutoSize = true;
            modifyProductMinLabel.Location = new Point(120, 370);
            modifyProductMinLabel.Name = "modifyProductMinLabel";
            modifyProductMinLabel.Size = new Size(28, 15);
            modifyProductMinLabel.TabIndex = 67;
            modifyProductMinLabel.Text = "Min";
            // 
            // modifyProductInStockLabel
            // 
            modifyProductInStockLabel.AutoSize = true;
            modifyProductInStockLabel.Location = new Point(120, 320);
            modifyProductInStockLabel.Name = "modifyProductInStockLabel";
            modifyProductInStockLabel.Size = new Size(33, 15);
            modifyProductInStockLabel.TabIndex = 66;
            modifyProductInStockLabel.Text = "Price";
            // 
            // modifyProductNameLabel
            // 
            modifyProductNameLabel.AutoSize = true;
            modifyProductNameLabel.Location = new Point(120, 220);
            modifyProductNameLabel.Name = "modifyProductNameLabel";
            modifyProductNameLabel.Size = new Size(39, 15);
            modifyProductNameLabel.TabIndex = 64;
            modifyProductNameLabel.Text = "Name";
            // 
            // modifyProductPriceLabel
            // 
            modifyProductPriceLabel.AutoSize = true;
            modifyProductPriceLabel.Location = new Point(120, 270);
            modifyProductPriceLabel.Name = "modifyProductPriceLabel";
            modifyProductPriceLabel.Size = new Size(33, 15);
            modifyProductPriceLabel.TabIndex = 65;
            modifyProductPriceLabel.Text = "Price";
            // 
            // modifyProductIDLabel
            // 
            modifyProductIDLabel.AutoSize = true;
            modifyProductIDLabel.Location = new Point(120, 170);
            modifyProductIDLabel.Name = "modifyProductIDLabel";
            modifyProductIDLabel.Size = new Size(63, 15);
            modifyProductIDLabel.TabIndex = 63;
            modifyProductIDLabel.Text = "Product ID";
            modifyProductIDLabel.TextAlign = ContentAlignment.TopRight;
            // 
            // modifyProductCancelButton
            // 
            modifyProductCancelButton.Location = new Point(842, 564);
            modifyProductCancelButton.Name = "modifyProductCancelButton";
            modifyProductCancelButton.Size = new Size(94, 43);
            modifyProductCancelButton.TabIndex = 62;
            modifyProductCancelButton.Text = "Cancel";
            modifyProductCancelButton.UseVisualStyleBackColor = true;
            modifyProductCancelButton.Click += modifyProductCancelButton_Click;
            // 
            // modifyProductSaveButton
            // 
            modifyProductSaveButton.Location = new Point(667, 564);
            modifyProductSaveButton.Name = "modifyProductSaveButton";
            modifyProductSaveButton.Size = new Size(94, 43);
            modifyProductSaveButton.TabIndex = 61;
            modifyProductSaveButton.Text = "Save";
            modifyProductSaveButton.UseVisualStyleBackColor = true;
            modifyProductSaveButton.Click += modifyProductSaveButton_Click;
            // 
            // modifyProductDeleteButton
            // 
            modifyProductDeleteButton.Location = new Point(1119, 397);
            modifyProductDeleteButton.Name = "modifyProductDeleteButton";
            modifyProductDeleteButton.Size = new Size(94, 43);
            modifyProductDeleteButton.TabIndex = 60;
            modifyProductDeleteButton.Text = "Delete";
            modifyProductDeleteButton.UseVisualStyleBackColor = true;
            modifyProductDeleteButton.Click += modifyProductDeleteButton_Click;
            // 
            // modifyProductAddButton
            // 
            modifyProductAddButton.Location = new Point(1119, 117);
            modifyProductAddButton.Name = "modifyProductAddButton";
            modifyProductAddButton.Size = new Size(94, 43);
            modifyProductAddButton.TabIndex = 59;
            modifyProductAddButton.Text = "Add";
            modifyProductAddButton.UseVisualStyleBackColor = true;
            modifyProductAddButton.Click += modifyProductAddButton_Click;
            // 
            // modifyProductsLabel
            // 
            modifyProductsLabel.AutoSize = true;
            modifyProductsLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            modifyProductsLabel.Location = new Point(12, 9);
            modifyProductsLabel.Name = "modifyProductsLabel";
            modifyProductsLabel.Size = new Size(150, 25);
            modifyProductsLabel.TabIndex = 75;
            modifyProductsLabel.Text = "Modify Products";
            // 
            // modifyProductAssociatedPartsSearchTextBox
            // 
            modifyProductAssociatedPartsSearchTextBox.Location = new Point(942, 283);
            modifyProductAssociatedPartsSearchTextBox.Name = "modifyProductAssociatedPartsSearchTextBox";
            modifyProductAssociatedPartsSearchTextBox.Size = new Size(171, 23);
            modifyProductAssociatedPartsSearchTextBox.TabIndex = 83;
            // 
            // modifyProductAssociatedPartsSearchButton
            // 
            modifyProductAssociatedPartsSearchButton.Location = new Point(869, 281);
            modifyProductAssociatedPartsSearchButton.Name = "modifyProductAssociatedPartsSearchButton";
            modifyProductAssociatedPartsSearchButton.Size = new Size(67, 28);
            modifyProductAssociatedPartsSearchButton.TabIndex = 82;
            modifyProductAssociatedPartsSearchButton.Text = "Search";
            modifyProductAssociatedPartsSearchButton.UseVisualStyleBackColor = true;
            modifyProductAssociatedPartsSearchButton.Click += modifyProductAssociatedPartsSearchButton_Click;
            // 
            // modifyProductsAssociatedPartsLabel
            // 
            modifyProductsAssociatedPartsLabel.AutoSize = true;
            modifyProductsAssociatedPartsLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            modifyProductsAssociatedPartsLabel.Location = new Point(518, 285);
            modifyProductsAssociatedPartsLabel.Name = "modifyProductsAssociatedPartsLabel";
            modifyProductsAssociatedPartsLabel.Size = new Size(243, 21);
            modifyProductsAssociatedPartsLabel.TabIndex = 81;
            modifyProductsAssociatedPartsLabel.Text = "Parts Associated with this Product";
            // 
            // modifyProductsAssociatedPartsDataGridView
            // 
            modifyProductsAssociatedPartsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            modifyProductsAssociatedPartsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            modifyProductsAssociatedPartsDataGridView.Location = new Point(518, 315);
            modifyProductsAssociatedPartsDataGridView.Name = "modifyProductsAssociatedPartsDataGridView";
            modifyProductsAssociatedPartsDataGridView.ReadOnly = true;
            modifyProductsAssociatedPartsDataGridView.RowHeadersVisible = false;
            modifyProductsAssociatedPartsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            modifyProductsAssociatedPartsDataGridView.Size = new Size(595, 203);
            modifyProductsAssociatedPartsDataGridView.TabIndex = 80;
            // 
            // modifyProductCandidatePartsSearchTextBox
            // 
            modifyProductCandidatePartsSearchTextBox.Location = new Point(942, 15);
            modifyProductCandidatePartsSearchTextBox.Name = "modifyProductCandidatePartsSearchTextBox";
            modifyProductCandidatePartsSearchTextBox.Size = new Size(171, 23);
            modifyProductCandidatePartsSearchTextBox.TabIndex = 79;
            // 
            // modifyProductCandidatePartsSearchButton
            // 
            modifyProductCandidatePartsSearchButton.Location = new Point(869, 11);
            modifyProductCandidatePartsSearchButton.Name = "modifyProductCandidatePartsSearchButton";
            modifyProductCandidatePartsSearchButton.Size = new Size(67, 28);
            modifyProductCandidatePartsSearchButton.TabIndex = 78;
            modifyProductCandidatePartsSearchButton.Text = "Search";
            modifyProductCandidatePartsSearchButton.UseVisualStyleBackColor = true;
            modifyProductCandidatePartsSearchButton.Click += modifyProductCandidatePartsSearchButton_Click;
            // 
            // modifyProductCandidatePartsLabel
            // 
            modifyProductCandidatePartsLabel.AutoSize = true;
            modifyProductCandidatePartsLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            modifyProductCandidatePartsLabel.Location = new Point(518, 13);
            modifyProductCandidatePartsLabel.Name = "modifyProductCandidatePartsLabel";
            modifyProductCandidatePartsLabel.Size = new Size(140, 21);
            modifyProductCandidatePartsLabel.TabIndex = 77;
            modifyProductCandidatePartsLabel.Text = "All Candidate Parts";
            // 
            // modifyProductsCandidatePartsDataGridView
            // 
            modifyProductsCandidatePartsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            modifyProductsCandidatePartsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            modifyProductsCandidatePartsDataGridView.Location = new Point(518, 45);
            modifyProductsCandidatePartsDataGridView.Name = "modifyProductsCandidatePartsDataGridView";
            modifyProductsCandidatePartsDataGridView.ReadOnly = true;
            modifyProductsCandidatePartsDataGridView.RowHeadersVisible = false;
            modifyProductsCandidatePartsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            modifyProductsCandidatePartsDataGridView.Size = new Size(595, 202);
            modifyProductsCandidatePartsDataGridView.TabIndex = 76;
            // 
            // modifyProductMaxTextBox
            // 
            modifyProductMaxTextBox.Location = new Point(183, 417);
            modifyProductMaxTextBox.Name = "modifyProductMaxTextBox";
            modifyProductMaxTextBox.Size = new Size(221, 23);
            modifyProductMaxTextBox.TabIndex = 89;
            // 
            // modifyProductMinTextBox
            // 
            modifyProductMinTextBox.Location = new Point(183, 367);
            modifyProductMinTextBox.Name = "modifyProductMinTextBox";
            modifyProductMinTextBox.Size = new Size(221, 23);
            modifyProductMinTextBox.TabIndex = 88;
            // 
            // modifyProductInStockTextBox
            // 
            modifyProductInStockTextBox.Location = new Point(183, 317);
            modifyProductInStockTextBox.Name = "modifyProductInStockTextBox";
            modifyProductInStockTextBox.Size = new Size(221, 23);
            modifyProductInStockTextBox.TabIndex = 87;
            // 
            // modifyProductPriceTextBox
            // 
            modifyProductPriceTextBox.Location = new Point(183, 267);
            modifyProductPriceTextBox.Name = "modifyProductPriceTextBox";
            modifyProductPriceTextBox.Size = new Size(221, 23);
            modifyProductPriceTextBox.TabIndex = 86;
            // 
            // modifyProductNameTextBox
            // 
            modifyProductNameTextBox.Location = new Point(183, 217);
            modifyProductNameTextBox.Name = "modifyProductNameTextBox";
            modifyProductNameTextBox.Size = new Size(221, 23);
            modifyProductNameTextBox.TabIndex = 85;
            // 
            // modifyProductIDTextBox
            // 
            modifyProductIDTextBox.Location = new Point(183, 167);
            modifyProductIDTextBox.Name = "modifyProductIDTextBox";
            modifyProductIDTextBox.Size = new Size(221, 23);
            modifyProductIDTextBox.TabIndex = 84;
            // 
            // ModifyProductForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1223, 619);
            Controls.Add(modifyProductMaxTextBox);
            Controls.Add(modifyProductMinTextBox);
            Controls.Add(modifyProductInStockTextBox);
            Controls.Add(modifyProductPriceTextBox);
            Controls.Add(modifyProductNameTextBox);
            Controls.Add(modifyProductIDTextBox);
            Controls.Add(modifyProductAssociatedPartsSearchTextBox);
            Controls.Add(modifyProductAssociatedPartsSearchButton);
            Controls.Add(modifyProductsAssociatedPartsLabel);
            Controls.Add(modifyProductsAssociatedPartsDataGridView);
            Controls.Add(modifyProductCandidatePartsSearchTextBox);
            Controls.Add(modifyProductCandidatePartsSearchButton);
            Controls.Add(modifyProductCandidatePartsLabel);
            Controls.Add(modifyProductsCandidatePartsDataGridView);
            Controls.Add(modifyProductsLabel);
            Controls.Add(modifyProductMaxLabel);
            Controls.Add(modifyProductMinLabel);
            Controls.Add(modifyProductInStockLabel);
            Controls.Add(modifyProductNameLabel);
            Controls.Add(modifyProductPriceLabel);
            Controls.Add(modifyProductIDLabel);
            Controls.Add(modifyProductCancelButton);
            Controls.Add(modifyProductSaveButton);
            Controls.Add(modifyProductDeleteButton);
            Controls.Add(modifyProductAddButton);
            Name = "ModifyProductForm";
            Text = "Modify Products Form";
            Activated += ModifyProductForm_Activated;
            Load += ModifyProductForm_Load;
            ((System.ComponentModel.ISupportInitialize)modifyProductsAssociatedPartsDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)modifyProductsCandidatePartsDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label modifyProductMaxLabel;
        private Label modifyProductMinLabel;
        private Label modifyProductInStockLabel;
        private Label modifyProductNameLabel;
        private Label modifyProductPriceLabel;
        private Label modifyProductIDLabel;
        private Button modifyProductCancelButton;
        private Button modifyProductSaveButton;
        private Button modifyProductDeleteButton;
        private Button modifyProductAddButton;
        private Label modifyProductsLabel;
        private TextBox modifyProductAssociatedPartsSearchTextBox;
        private Button modifyProductAssociatedPartsSearchButton;
        private Label modifyProductsAssociatedPartsLabel;
        private DataGridView modifyProductsAssociatedPartsDataGridView;
        private TextBox modifyProductCandidatePartsSearchTextBox;
        private Button modifyProductCandidatePartsSearchButton;
        private Label modifyProductCandidatePartsLabel;
        private DataGridView modifyProductsCandidatePartsDataGridView;
        private TextBox modifyProductMaxTextBox;
        private TextBox modifyProductMinTextBox;
        private TextBox modifyProductInStockTextBox;
        private TextBox modifyProductPriceTextBox;
        private TextBox modifyProductNameTextBox;
        private TextBox modifyProductIDTextBox;
    }
}
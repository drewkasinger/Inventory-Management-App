﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsDemo
{
    public partial class ModifyPartForm : Form
    {
        string radioChecker = "";
        
        public ModifyPartForm(Part part)
        {
            InitializeComponent();

            modifyPartIDTextBox.Text = part.PartID.ToString();
            modifyPartNameTextBox.Text = part.Name;
            modifyPartPriceTextBox.Text = part.Price.ToString();
            modifyPartInStockTextBox.Text = part.InStock.ToString();
            modifyPartMinTextBox.Text = part.Min.ToString();
            modifyPartMaxTextBox.Text = part.Max.ToString();
            if (part is Inhouse)
            {
                modifyPartInHouseRadio.Checked = true;
                modifyPartTempTextBox.Text = "Machine ID";

                Inhouse myinhouse = (Inhouse)part;
                modifyPartTempTextBox.Text = myinhouse.MachineID.ToString();
            }
            else
            {
                 modifyPartOutsourcedRadio.Checked = true;
                modifyPartTempTextBox.Text = "Company Name";

                Outsourced myoutsourced = (Outsourced)part;
                modifyPartTempTextBox.Text = myoutsourced.CompanyName;
            }
        }
        private void modifyPartSaveButton_Click(object sender, EventArgs e)
        {
            if (radioChecker == "In-House")
            {
                inhouseValidation();
            }
            else if (radioChecker == "Outsourced")
            {
                outsourcedValidation();
            }
            else
            {
                MessageBox.Show("Please select In-House or Outsourced");
            }
        }

        private void modifyPartCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void modifyPartInHouseRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (modifyPartInHouseRadio.Checked)
            {
                radioChecker = "In-House";
                modifyPartTempLabel.Text = "Machine ID";
            }
        }

        private void modifyPartOutsourcedRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (modifyPartOutsourcedRadio.Checked)
            {
                radioChecker = "Outsourced";
                modifyPartTempLabel.Text = "Company Name";
            }
        }
        public void inhouseValidation()
        {
            if (
                string.IsNullOrEmpty(modifyPartNameTextBox.Text))
                MessageBox.Show("Please enter infomation for Name");
            else if (inhousetextbox() != null)
            {
                MessageBox.Show(inhousetextbox());
                return;
            }
            else if (minmaxvalidation() != null)
            {
                MessageBox.Show(minmaxvalidation());
                return;
            }
            else
            {
                modifyInHousePart();
            }
        }
        public void outsourcedValidation()
        {
            if (string.IsNullOrEmpty(modifyPartNameTextBox.Text))
                MessageBox.Show("Please enter infomation for Name");
            else if (outsourcedtextbox() != null)
            {
                MessageBox.Show(outsourcedtextbox());
                return;
            }
            else if (string.IsNullOrEmpty(modifyPartTempTextBox.Text))
                MessageBox.Show("Please enter infomation for Company Name");
            else if (minmaxvalidation() != null)
            {
                MessageBox.Show(minmaxvalidation());
                return;
            }
            else
            {
                modifyOutsourcedPart();
            }
        }

        public void modifyInHousePart()
        {

            Part modifyPart = new Inhouse
            {
                PartID = int.Parse(modifyPartIDTextBox.Text),
                Name = modifyPartNameTextBox.Text,
                Price = decimal.Parse(modifyPartPriceTextBox.Text),
                InStock = int.Parse(modifyPartInStockTextBox.Text),
                Min = int.Parse(modifyPartMinTextBox.Text),
                Max = int.Parse(modifyPartMaxTextBox.Text),
                MachineID = int.Parse(modifyPartTempTextBox.Text)
            };
            Inventory.updatePart(modifyPart.PartID, modifyPart);
            this.Close();
        }
        public void modifyOutsourcedPart()
        {

            Part modifyPart = new Outsourced
            {
                PartID = int.Parse(modifyPartIDTextBox.Text),
                Name = modifyPartNameTextBox.Text,
                Price = decimal.Parse(modifyPartPriceTextBox.Text),
                InStock = int.Parse(modifyPartInStockTextBox.Text),
                Min = int.Parse(modifyPartMinTextBox.Text),
                Max = int.Parse(modifyPartMaxTextBox.Text),
                CompanyName = modifyPartTempTextBox.Text
            };
            Inventory.updatePart(modifyPart.PartID, modifyPart);
            this.Close();
        }

        public string inhousetextbox()
        {
            int price;
            bool pricetextbox = int.TryParse(modifyPartPriceTextBox.Text, out price);
            if (!pricetextbox)
            {
                return "Price must be a number";
            }

            int instock;
            bool instocktextbox = int.TryParse(modifyPartInStockTextBox.Text, out instock);
            if (!instocktextbox)
            {
                return "InStock must be a number";
            }

            int min;
            bool mintextbox = int.TryParse(modifyPartMinTextBox.Text, out min);
            if (!mintextbox)
            {
                return "Min must be a number";
            }

            int max;
            bool maxtempbox = int.TryParse(modifyPartMaxTextBox.Text, out max);
            if (!maxtempbox)
            {
                return "Max must be a number";
            }

            int temp;
            bool temptextbox = int.TryParse(modifyPartTempTextBox.Text, out temp);
            if (!temptextbox)
            {
                return "Machine ID must be a number";
            }
            return null;
        }
        public string outsourcedtextbox()
        {
            int price;
            bool pricetextbox = int.TryParse(modifyPartPriceTextBox.Text, out price);
            if (!pricetextbox)
            {
                return "Price must be a number";
            }

            int instock;
            bool instocktextbox = int.TryParse(modifyPartInStockTextBox.Text, out instock);
            if (!instocktextbox)
            {
                return "InStock must be a number";
            }

            int min;
            bool mintextbox = int.TryParse(modifyPartMinTextBox.Text, out min);
            if (!mintextbox)
            {
                return "Min must be a number";
            }

            int max;
            bool maxtempbox = int.TryParse(modifyPartMaxTextBox.Text, out max);
            if (!maxtempbox)
            {
                return "Max must be a number";
            }
            return null;
        }

        public string minmaxvalidation()
        {
            if (int.Parse(modifyPartMinTextBox.Text) > int.Parse(modifyPartMaxTextBox.Text))
            {
                return "Min must be less then or equal to Max.";
            }
            if (int.Parse(modifyPartInStockTextBox.Text) < int.Parse(modifyPartMinTextBox.Text))
            {
                return "InStock must be larger then Min.";
            }
            if (int.Parse(modifyPartInStockTextBox.Text) > int.Parse(modifyPartMaxTextBox.Text))
            {
                return "InStock must be Smaller then Max.";
            }
            return null;
        }
    }
}

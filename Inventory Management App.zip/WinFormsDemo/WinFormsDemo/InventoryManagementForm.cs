using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;

namespace WinFormsDemo
{

    public partial class InventoryManagementForm : Form
    {
        public InventoryManagementForm()
        {
            InitializeComponent();

        }

        public void InventroyHomePage_Load(object sender, EventArgs e)
        {
            homePartsDataGridView.DataSource = Inventory.AllParts;
            homeProductsDataGridView.DataSource = Inventory.Products;
        }

        public void InventroyManagementForm_Activated(object sender, EventArgs e)
        {
            homePartsDataGridView.ClearSelection();
            homeProductsDataGridView.ClearSelection();
        }

        public void addPartsButton_Click(object sender, EventArgs e)
        {
            AddPartForm addPartsForm = new AddPartForm();
            addPartsForm.ShowDialog();
        }

        public void modifyPartsButton_Click(object sender, EventArgs e)
        {
            //this stops program from throwing an error when nothing is in the list
            if (homePartsDataGridView.CurrentRow == null)
            {
                MessageBox.Show("There is nothing to modify.");
                return;
            }
            if (!homePartsDataGridView.CurrentRow.Selected)
            {
                MessageBox.Show("Nothing Selected, Please Make a Selection");
                return;
            }
            var modifyPartForm = new ModifyPartForm((Part)homePartsDataGridView.CurrentRow.DataBoundItem);
            modifyPartForm.ShowDialog();
        }

        public void deletePartsButton_Click(object sender, EventArgs e)
        {
            //this stops program from throwing an error when nothing is in the list
            if (homePartsDataGridView.CurrentRow == null)
            {
                MessageBox.Show("There is nothing to delete.");
                return;
            }
            else if (!homePartsDataGridView.CurrentRow.Selected)
            {
                MessageBox.Show("Nothing Selected, Please Make a Selection");
                return;
            }

            if (checkforassociatedparts() != null)
            {
                MessageBox.Show(checkforassociatedparts());
                return;
            }

            //this brings up the confirmation window
            if (MessageBox.Show("Are you sure you want to delete this part?", "Delete Part?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int rowIndex = homePartsDataGridView.CurrentCell.RowIndex;
                Inventory.AllParts.RemoveAt(rowIndex);
            }

        }

        public void partsSearchButton_Click(object sender, EventArgs e)
        {
            homePartsDataGridView.ClearSelection();
            try
            {
                var locatePart = Inventory.lookupPart(int.Parse(partsSearchTextbox.Text));
                if (locatePart == null)
                {
                    MessageBox.Show("No Part Found, Please enter entire PartID number.");
                    return;
                }
                string partIDValue = partsSearchTextbox.Text;
                int rowIndex;
                foreach (DataGridViewRow row in homePartsDataGridView.Rows)
                {
                    if (row.Cells[0].Value.ToString() == partIDValue)
                    {
                        rowIndex = row.Cells[0].RowIndex;
                        homePartsDataGridView.Rows[rowIndex].Selected = true;
                        break;
                    }
                }
            }
            catch { return; }
        }

        public void addProductsButton_Click(object sender, EventArgs e)
        {
            AddProductForm addProductsForm = new AddProductForm();
            addProductsForm.ShowDialog();
        }

        public void modifyProductsButton_Click(object sender, EventArgs e)
        {
            //this stops program from throwing an error when nothing is in the list
            if (homeProductsDataGridView.CurrentRow == null)
            {
                MessageBox.Show("There is nothing to modify.");
                return;
            }
            if (!homeProductsDataGridView.CurrentRow.Selected)
            {
                MessageBox.Show("Nothing Selected, Please Make a Selection");
                return;
            }
            var modifyProductForm = new ModifyProductForm((Product)homeProductsDataGridView.CurrentRow.DataBoundItem);
            modifyProductForm.ShowDialog();
        }

        public void deleteProductsButton_Click(object sender, EventArgs e)
        {
            //this stops program from throwing an error when nothing is in the list
            if (homeProductsDataGridView.CurrentRow == null)
            {
                MessageBox.Show("There is nothing to delete.");
                return;
            }
            if (!homeProductsDataGridView.CurrentRow.Selected)
            {
                MessageBox.Show("Nothing Selected, Please Make a Selection");
                return;
            }
            //this brings up the confirmation window
            if (MessageBox.Show("Are you sure you want to delete this product?", "Delete Product?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int rowIndex = homeProductsDataGridView.CurrentCell.RowIndex;
                Inventory.Products.RemoveAt(rowIndex);
            }
        }

        public void productsSearchButton_Click(object sender, EventArgs e)
        {
            homeProductsDataGridView.ClearSelection();
            try
            {
                var locatePart = Inventory.lookupProduct(int.Parse(productsSearchTextbox.Text));
                if (locatePart == null)
                {
                    MessageBox.Show("No Part Found, Please enter entire ProductID number.");
                }
                string productIDValue = productsSearchTextbox.Text;
                int rowIndex;
                foreach (DataGridViewRow row in homeProductsDataGridView.Rows)
                {
                    if (row.Cells[0].Value.ToString() == productIDValue)
                    {
                        rowIndex = row.Cells[0].RowIndex;
                        homeProductsDataGridView.Rows[rowIndex].Selected = true;
                        break;
                    }
                }
            }
            catch { return; }
        }

        public void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public string checkforassociatedparts()
        {
            int rowIndex = homePartsDataGridView.CurrentCell.RowIndex;
            int checkpartid = (int)homePartsDataGridView.Rows[rowIndex].Cells[0].Value;
            Product allproduct = new Product();
            Product checkproduct = new Product();
            Part checkpart = Inventory.lookupPart(checkpartid);

            foreach (DataGridViewRow productrow in homeProductsDataGridView.Rows)
            {
                allproduct = ((Product)productrow.DataBoundItem);
                checkproduct.AssociatedParts = allproduct.AssociatedParts;
                foreach (Part associatepart in checkproduct.AssociatedParts)
                {


                    if (checkpart.PartID == associatepart.PartID)
                    {
                        return "This part is associated with '" + allproduct.Name + "' and can not be deleted until it is removed from that product.";
                    }
                }
            }
            return null;
        }
    }
}

//should have atleast 1 associated part added with AddProductForm, should be easy
//ModifyProductForm must revert to original associatedparts list when pressing cancel, middle ground

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsDemo
{
    
    public class Product
    {
        public BindingList<Part> AssociatedParts { get; set; } = new BindingList<Part>();
        public int ProductID { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int InStock { get; set; }
        public int Min { get; set; }
        public int Max { get; set; }

        public void addAssociatedPart(Part part)
        {
            AssociatedParts.Add(part);
        }
        public bool removeAssociatedPart(int id)
        {
            Part deletePart = lookupAssociatedPart(id);
            if (deletePart != null)
            {
                AssociatedParts.Remove(deletePart);
                return true;
            }
            return false;
        }
        public Part lookupAssociatedPart(int id)
        {
            foreach (Part part in AssociatedParts)
            {
                if (id == part.PartID)
                {
                    return part;
                }
            }
            return null;
        }
    }

}

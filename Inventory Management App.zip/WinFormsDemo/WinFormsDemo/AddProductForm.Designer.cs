﻿namespace WinFormsDemo
{
    partial class AddProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addProductAddButton = new Button();
            addProductDeleteButton = new Button();
            addProductSaveButton = new Button();
            addProductCancelButton = new Button();
            addProductMaxLabel = new Label();
            addProductMinLabel = new Label();
            addProductPriceLabel = new Label();
            addProductNameLabel = new Label();
            addProductInStockLabel = new Label();
            addProductIDLabel = new Label();
            addProductsLabel = new Label();
            addProductCandidatePartsSearchTextBox = new TextBox();
            addProductCandidatePartsSearchButton = new Button();
            addProductCandidatePartsLabel = new Label();
            addProductsCandidatePartsDataGridView = new DataGridView();
            addProductAssociatedPartsSearchTextBox = new TextBox();
            addProductAssociatedPartsSearchButton = new Button();
            addProductsAssociatedPartsLabel = new Label();
            addProductsAssociatedPartsDataGridView = new DataGridView();
            addProductMaxTextBox = new TextBox();
            addProductMinTextBox = new TextBox();
            addProductInStockTextBox = new TextBox();
            addProductPriceTextBox = new TextBox();
            addProductNameTextBox = new TextBox();
            addProductIDTextBox = new TextBox();
            ((System.ComponentModel.ISupportInitialize)addProductsCandidatePartsDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)addProductsAssociatedPartsDataGridView).BeginInit();
            SuspendLayout();
            // 
            // addProductAddButton
            // 
            addProductAddButton.Location = new Point(1118, 121);
            addProductAddButton.Name = "addProductAddButton";
            addProductAddButton.Size = new Size(94, 43);
            addProductAddButton.TabIndex = 0;
            addProductAddButton.Text = "Add";
            addProductAddButton.UseVisualStyleBackColor = true;
            addProductAddButton.Click += addProductAddButton_Click;
            // 
            // addProductDeleteButton
            // 
            addProductDeleteButton.Location = new Point(1118, 392);
            addProductDeleteButton.Name = "addProductDeleteButton";
            addProductDeleteButton.Size = new Size(94, 43);
            addProductDeleteButton.TabIndex = 1;
            addProductDeleteButton.Text = "Delete";
            addProductDeleteButton.UseVisualStyleBackColor = true;
            addProductDeleteButton.Click += addProductDeleteButton_Click;
            // 
            // addProductSaveButton
            // 
            addProductSaveButton.Location = new Point(666, 563);
            addProductSaveButton.Name = "addProductSaveButton";
            addProductSaveButton.Size = new Size(94, 43);
            addProductSaveButton.TabIndex = 2;
            addProductSaveButton.Text = "Save";
            addProductSaveButton.UseVisualStyleBackColor = true;
            addProductSaveButton.Click += addProductSaveButton_Click;
            // 
            // addProductCancelButton
            // 
            addProductCancelButton.Location = new Point(841, 563);
            addProductCancelButton.Name = "addProductCancelButton";
            addProductCancelButton.Size = new Size(94, 43);
            addProductCancelButton.TabIndex = 3;
            addProductCancelButton.Text = "Cancel";
            addProductCancelButton.UseVisualStyleBackColor = true;
            addProductCancelButton.Click += addProductCancelButton_Click;
            // 
            // addProductMaxLabel
            // 
            addProductMaxLabel.AutoSize = true;
            addProductMaxLabel.Location = new Point(95, 420);
            addProductMaxLabel.Name = "addProductMaxLabel";
            addProductMaxLabel.Size = new Size(29, 15);
            addProductMaxLabel.TabIndex = 52;
            addProductMaxLabel.Text = "Max";
            // 
            // addProductMinLabel
            // 
            addProductMinLabel.AutoSize = true;
            addProductMinLabel.Location = new Point(95, 370);
            addProductMinLabel.Name = "addProductMinLabel";
            addProductMinLabel.Size = new Size(28, 15);
            addProductMinLabel.TabIndex = 51;
            addProductMinLabel.Text = "Min";
            // 
            // addProductPriceLabel
            // 
            addProductPriceLabel.AutoSize = true;
            addProductPriceLabel.Location = new Point(95, 270);
            addProductPriceLabel.Name = "addProductPriceLabel";
            addProductPriceLabel.Size = new Size(33, 15);
            addProductPriceLabel.TabIndex = 50;
            addProductPriceLabel.Text = "Price";
            // 
            // addProductNameLabel
            // 
            addProductNameLabel.AutoSize = true;
            addProductNameLabel.Location = new Point(95, 220);
            addProductNameLabel.Name = "addProductNameLabel";
            addProductNameLabel.Size = new Size(39, 15);
            addProductNameLabel.TabIndex = 48;
            addProductNameLabel.Text = "Name";
            // 
            // addProductInStockLabel
            // 
            addProductInStockLabel.AutoSize = true;
            addProductInStockLabel.Location = new Point(95, 320);
            addProductInStockLabel.Name = "addProductInStockLabel";
            addProductInStockLabel.Size = new Size(46, 15);
            addProductInStockLabel.TabIndex = 49;
            addProductInStockLabel.Text = "InStock";
            // 
            // addProductIDLabel
            // 
            addProductIDLabel.AutoSize = true;
            addProductIDLabel.Location = new Point(95, 170);
            addProductIDLabel.Name = "addProductIDLabel";
            addProductIDLabel.Size = new Size(42, 15);
            addProductIDLabel.TabIndex = 47;
            addProductIDLabel.Text = "Part ID";
            addProductIDLabel.TextAlign = ContentAlignment.TopRight;
            // 
            // addProductsLabel
            // 
            addProductsLabel.AutoSize = true;
            addProductsLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addProductsLabel.Location = new Point(12, 9);
            addProductsLabel.Name = "addProductsLabel";
            addProductsLabel.Size = new Size(125, 25);
            addProductsLabel.TabIndex = 59;
            addProductsLabel.Text = "Add Products";
            // 
            // addProductCandidatePartsSearchTextBox
            // 
            addProductCandidatePartsSearchTextBox.Location = new Point(941, 16);
            addProductCandidatePartsSearchTextBox.Name = "addProductCandidatePartsSearchTextBox";
            addProductCandidatePartsSearchTextBox.Size = new Size(171, 23);
            addProductCandidatePartsSearchTextBox.TabIndex = 63;
            // 
            // addProductCandidatePartsSearchButton
            // 
            addProductCandidatePartsSearchButton.Location = new Point(868, 12);
            addProductCandidatePartsSearchButton.Name = "addProductCandidatePartsSearchButton";
            addProductCandidatePartsSearchButton.Size = new Size(67, 28);
            addProductCandidatePartsSearchButton.TabIndex = 62;
            addProductCandidatePartsSearchButton.Text = "Search";
            addProductCandidatePartsSearchButton.UseVisualStyleBackColor = true;
            addProductCandidatePartsSearchButton.Click += addProductCandidatePartsSearchButton_Click;
            // 
            // addProductCandidatePartsLabel
            // 
            addProductCandidatePartsLabel.AutoSize = true;
            addProductCandidatePartsLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addProductCandidatePartsLabel.Location = new Point(517, 14);
            addProductCandidatePartsLabel.Name = "addProductCandidatePartsLabel";
            addProductCandidatePartsLabel.Size = new Size(140, 21);
            addProductCandidatePartsLabel.TabIndex = 61;
            addProductCandidatePartsLabel.Text = "All Candidate Parts";
            // 
            // addProductsCandidatePartsDataGridView
            // 
            addProductsCandidatePartsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            addProductsCandidatePartsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            addProductsCandidatePartsDataGridView.Location = new Point(517, 46);
            addProductsCandidatePartsDataGridView.Name = "addProductsCandidatePartsDataGridView";
            addProductsCandidatePartsDataGridView.ReadOnly = true;
            addProductsCandidatePartsDataGridView.RowHeadersVisible = false;
            addProductsCandidatePartsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            addProductsCandidatePartsDataGridView.Size = new Size(595, 202);
            addProductsCandidatePartsDataGridView.TabIndex = 60;
            // 
            // addProductAssociatedPartsSearchTextBox
            // 
            addProductAssociatedPartsSearchTextBox.Location = new Point(941, 284);
            addProductAssociatedPartsSearchTextBox.Name = "addProductAssociatedPartsSearchTextBox";
            addProductAssociatedPartsSearchTextBox.Size = new Size(171, 23);
            addProductAssociatedPartsSearchTextBox.TabIndex = 67;
            // 
            // addProductAssociatedPartsSearchButton
            // 
            addProductAssociatedPartsSearchButton.Location = new Point(868, 282);
            addProductAssociatedPartsSearchButton.Name = "addProductAssociatedPartsSearchButton";
            addProductAssociatedPartsSearchButton.Size = new Size(67, 28);
            addProductAssociatedPartsSearchButton.TabIndex = 66;
            addProductAssociatedPartsSearchButton.Text = "Search";
            addProductAssociatedPartsSearchButton.UseVisualStyleBackColor = true;
            addProductAssociatedPartsSearchButton.Click += addProductAssociatedPartsSearchButton_Click;
            // 
            // addProductsAssociatedPartsLabel
            // 
            addProductsAssociatedPartsLabel.AutoSize = true;
            addProductsAssociatedPartsLabel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addProductsAssociatedPartsLabel.Location = new Point(517, 286);
            addProductsAssociatedPartsLabel.Name = "addProductsAssociatedPartsLabel";
            addProductsAssociatedPartsLabel.Size = new Size(243, 21);
            addProductsAssociatedPartsLabel.TabIndex = 65;
            addProductsAssociatedPartsLabel.Text = "Parts Associated with this Product";
            // 
            // addProductsAssociatedPartsDataGridView
            // 
            addProductsAssociatedPartsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            addProductsAssociatedPartsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            addProductsAssociatedPartsDataGridView.Location = new Point(517, 316);
            addProductsAssociatedPartsDataGridView.Name = "addProductsAssociatedPartsDataGridView";
            addProductsAssociatedPartsDataGridView.ReadOnly = true;
            addProductsAssociatedPartsDataGridView.RowHeadersVisible = false;
            addProductsAssociatedPartsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            addProductsAssociatedPartsDataGridView.Size = new Size(595, 203);
            addProductsAssociatedPartsDataGridView.TabIndex = 64;
            // 
            // addProductMaxTextBox
            // 
            addProductMaxTextBox.Location = new Point(158, 417);
            addProductMaxTextBox.Name = "addProductMaxTextBox";
            addProductMaxTextBox.Size = new Size(221, 23);
            addProductMaxTextBox.TabIndex = 73;
            // 
            // addProductMinTextBox
            // 
            addProductMinTextBox.Location = new Point(158, 367);
            addProductMinTextBox.Name = "addProductMinTextBox";
            addProductMinTextBox.Size = new Size(221, 23);
            addProductMinTextBox.TabIndex = 72;
            // 
            // addProductInStockTextBox
            // 
            addProductInStockTextBox.Location = new Point(158, 317);
            addProductInStockTextBox.Name = "addProductInStockTextBox";
            addProductInStockTextBox.Size = new Size(221, 23);
            addProductInStockTextBox.TabIndex = 71;
            // 
            // addProductPriceTextBox
            // 
            addProductPriceTextBox.Location = new Point(158, 267);
            addProductPriceTextBox.Name = "addProductPriceTextBox";
            addProductPriceTextBox.Size = new Size(221, 23);
            addProductPriceTextBox.TabIndex = 70;
            // 
            // addProductNameTextBox
            // 
            addProductNameTextBox.Location = new Point(158, 217);
            addProductNameTextBox.Name = "addProductNameTextBox";
            addProductNameTextBox.Size = new Size(221, 23);
            addProductNameTextBox.TabIndex = 69;
            // 
            // addProductIDTextBox
            // 
            addProductIDTextBox.Enabled = false;
            addProductIDTextBox.Location = new Point(158, 167);
            addProductIDTextBox.Name = "addProductIDTextBox";
            addProductIDTextBox.Size = new Size(221, 23);
            addProductIDTextBox.TabIndex = 68;
            // 
            // AddProductForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1224, 618);
            Controls.Add(addProductMaxTextBox);
            Controls.Add(addProductMinTextBox);
            Controls.Add(addProductInStockTextBox);
            Controls.Add(addProductPriceTextBox);
            Controls.Add(addProductNameTextBox);
            Controls.Add(addProductIDTextBox);
            Controls.Add(addProductAssociatedPartsSearchTextBox);
            Controls.Add(addProductAssociatedPartsSearchButton);
            Controls.Add(addProductsAssociatedPartsLabel);
            Controls.Add(addProductsAssociatedPartsDataGridView);
            Controls.Add(addProductCandidatePartsSearchTextBox);
            Controls.Add(addProductCandidatePartsSearchButton);
            Controls.Add(addProductCandidatePartsLabel);
            Controls.Add(addProductsCandidatePartsDataGridView);
            Controls.Add(addProductsLabel);
            Controls.Add(addProductMaxLabel);
            Controls.Add(addProductMinLabel);
            Controls.Add(addProductPriceLabel);
            Controls.Add(addProductNameLabel);
            Controls.Add(addProductInStockLabel);
            Controls.Add(addProductIDLabel);
            Controls.Add(addProductCancelButton);
            Controls.Add(addProductSaveButton);
            Controls.Add(addProductDeleteButton);
            Controls.Add(addProductAddButton);
            Name = "AddProductForm";
            Text = "Add Products Form";
            Activated += AddProductForm_Activated;
            Load += AddProductForm_Load;
            ((System.ComponentModel.ISupportInitialize)addProductsCandidatePartsDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)addProductsAssociatedPartsDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button addProductAddButton;
        private Button addProductDeleteButton;
        private Button addProductSaveButton;
        private Button addProductCancelButton;
        private Label addProductMaxLabel;
        private Label addProductMinLabel;
        private Label addProductPriceLabel;
        private Label addProductNameLabel;
        private Label addProductInStockLabel;
        private Label addProductIDLabel;
        private Label addProductsLabel;
        private TextBox addProductCandidatePartsSearchTextBox;
        private Button addProductCandidatePartsSearchButton;
        private Label addProductCandidatePartsLabel;
        private DataGridView addProductsCandidatePartsDataGridView;
        private TextBox addProductAssociatedPartsSearchTextBox;
        private Button addProductAssociatedPartsSearchButton;
        private Label addProductsAssociatedPartsLabel;
        private DataGridView addProductsAssociatedPartsDataGridView;
        private TextBox addProductMaxTextBox;
        private TextBox addProductMinTextBox;
        private TextBox addProductInStockTextBox;
        private TextBox addProductPriceTextBox;
        private TextBox addProductNameTextBox;
        private TextBox addProductIDTextBox;
    }
}
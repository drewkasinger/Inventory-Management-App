﻿namespace WinFormsDemo
{
    partial class InventoryManagementForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            homePartsDataGridView = new DataGridView();
            productsSearchTextbox = new TextBox();
            partsSearchTextbox = new TextBox();
            partsSearchButton = new Button();
            addProductsButton = new Button();
            productsSearchButton = new Button();
            exitButton = new Button();
            deleteProductsButton = new Button();
            homePageProductsLabel = new Label();
            homePagePartsLabel = new Label();
            modifyProductsButton = new Button();
            deletePartsButton = new Button();
            modifyPartsButton = new Button();
            homeProductsDataGridView = new DataGridView();
            addPartsButton = new Button();
            homePageNameLabel = new Label();
            ((System.ComponentModel.ISupportInitialize)homePartsDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)homeProductsDataGridView).BeginInit();
            SuspendLayout();
            // 
            // homePartsDataGridView
            // 
            homePartsDataGridView.AllowUserToAddRows = false;
            homePartsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            homePartsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            homePartsDataGridView.Location = new Point(12, 110);
            homePartsDataGridView.Name = "homePartsDataGridView";
            homePartsDataGridView.ReadOnly = true;
            homePartsDataGridView.RowHeadersVisible = false;
            homePartsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            homePartsDataGridView.Size = new Size(595, 238);
            homePartsDataGridView.TabIndex = 6;
            // 
            // productsSearchTextbox
            // 
            productsSearchTextbox.Location = new Point(1179, 70);
            productsSearchTextbox.Name = "productsSearchTextbox";
            productsSearchTextbox.Size = new Size(171, 23);
            productsSearchTextbox.TabIndex = 61;
            // 
            // partsSearchTextbox
            // 
            partsSearchTextbox.Location = new Point(436, 70);
            partsSearchTextbox.Name = "partsSearchTextbox";
            partsSearchTextbox.Size = new Size(171, 23);
            partsSearchTextbox.TabIndex = 60;
            // 
            // partsSearchButton
            // 
            partsSearchButton.Location = new Point(363, 66);
            partsSearchButton.Name = "partsSearchButton";
            partsSearchButton.Size = new Size(67, 28);
            partsSearchButton.TabIndex = 59;
            partsSearchButton.Text = "Search";
            partsSearchButton.UseVisualStyleBackColor = true;
            partsSearchButton.Click += partsSearchButton_Click;
            // 
            // addProductsButton
            // 
            addProductsButton.Location = new Point(755, 363);
            addProductsButton.Name = "addProductsButton";
            addProductsButton.Size = new Size(95, 33);
            addProductsButton.TabIndex = 58;
            addProductsButton.Text = "Add";
            addProductsButton.UseVisualStyleBackColor = true;
            addProductsButton.Click += addProductsButton_Click;
            // 
            // productsSearchButton
            // 
            productsSearchButton.Location = new Point(1109, 66);
            productsSearchButton.Name = "productsSearchButton";
            productsSearchButton.Size = new Size(67, 28);
            productsSearchButton.TabIndex = 57;
            productsSearchButton.Text = "Search";
            productsSearchButton.UseVisualStyleBackColor = true;
            productsSearchButton.Click += productsSearchButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(1254, 460);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(96, 38);
            exitButton.TabIndex = 56;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // deleteProductsButton
            // 
            deleteProductsButton.Location = new Point(1255, 363);
            deleteProductsButton.Name = "deleteProductsButton";
            deleteProductsButton.Size = new Size(95, 33);
            deleteProductsButton.TabIndex = 55;
            deleteProductsButton.Text = "Delete";
            deleteProductsButton.UseVisualStyleBackColor = true;
            deleteProductsButton.Click += deleteProductsButton_Click;
            // 
            // homePageProductsLabel
            // 
            homePageProductsLabel.AutoSize = true;
            homePageProductsLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            homePageProductsLabel.Location = new Point(755, 72);
            homePageProductsLabel.Name = "homePageProductsLabel";
            homePageProductsLabel.Size = new Size(86, 25);
            homePageProductsLabel.TabIndex = 54;
            homePageProductsLabel.Text = "Products";
            // 
            // homePagePartsLabel
            // 
            homePagePartsLabel.AutoSize = true;
            homePagePartsLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            homePagePartsLabel.Location = new Point(12, 72);
            homePagePartsLabel.Name = "homePagePartsLabel";
            homePagePartsLabel.Size = new Size(53, 25);
            homePagePartsLabel.TabIndex = 53;
            homePagePartsLabel.Text = "Parts";
            // 
            // modifyProductsButton
            // 
            modifyProductsButton.Location = new Point(1008, 363);
            modifyProductsButton.Name = "modifyProductsButton";
            modifyProductsButton.Size = new Size(95, 33);
            modifyProductsButton.TabIndex = 52;
            modifyProductsButton.Text = "Modify";
            modifyProductsButton.UseVisualStyleBackColor = true;
            modifyProductsButton.Click += modifyProductsButton_Click;
            // 
            // deletePartsButton
            // 
            deletePartsButton.Location = new Point(512, 363);
            deletePartsButton.Name = "deletePartsButton";
            deletePartsButton.Size = new Size(95, 33);
            deletePartsButton.TabIndex = 50;
            deletePartsButton.Text = "Delete";
            deletePartsButton.UseVisualStyleBackColor = true;
            deletePartsButton.Click += deletePartsButton_Click;
            // 
            // modifyPartsButton
            // 
            modifyPartsButton.Location = new Point(262, 363);
            modifyPartsButton.Name = "modifyPartsButton";
            modifyPartsButton.Size = new Size(95, 33);
            modifyPartsButton.TabIndex = 49;
            modifyPartsButton.Text = "Modify";
            modifyPartsButton.UseVisualStyleBackColor = true;
            modifyPartsButton.Click += modifyPartsButton_Click;
            // 
            // homeProductsDataGridView
            // 
            homeProductsDataGridView.AllowUserToAddRows = false;
            homeProductsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            homeProductsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            homeProductsDataGridView.Location = new Point(755, 110);
            homeProductsDataGridView.Name = "homeProductsDataGridView";
            homeProductsDataGridView.ReadOnly = true;
            homeProductsDataGridView.RowHeadersVisible = false;
            homeProductsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            homeProductsDataGridView.Size = new Size(595, 238);
            homeProductsDataGridView.TabIndex = 48;
            // 
            // addPartsButton
            // 
            addPartsButton.Location = new Point(12, 363);
            addPartsButton.Name = "addPartsButton";
            addPartsButton.Size = new Size(95, 33);
            addPartsButton.TabIndex = 47;
            addPartsButton.Text = "Add";
            addPartsButton.UseVisualStyleBackColor = true;
            addPartsButton.Click += addPartsButton_Click;
            // 
            // homePageNameLabel
            // 
            homePageNameLabel.AutoSize = true;
            homePageNameLabel.Location = new Point(12, 9);
            homePageNameLabel.Name = "homePageNameLabel";
            homePageNameLabel.Size = new Size(172, 15);
            homePageNameLabel.TabIndex = 46;
            homePageNameLabel.Text = "Inventory Management System";
            // 
            // InventoryManagementForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1362, 510);
            Controls.Add(homePartsDataGridView);
            Controls.Add(productsSearchTextbox);
            Controls.Add(partsSearchTextbox);
            Controls.Add(partsSearchButton);
            Controls.Add(addProductsButton);
            Controls.Add(productsSearchButton);
            Controls.Add(exitButton);
            Controls.Add(deleteProductsButton);
            Controls.Add(homePageProductsLabel);
            Controls.Add(homePagePartsLabel);
            Controls.Add(modifyProductsButton);
            Controls.Add(deletePartsButton);
            Controls.Add(modifyPartsButton);
            Controls.Add(homeProductsDataGridView);
            Controls.Add(addPartsButton);
            Controls.Add(homePageNameLabel);
            Name = "InventoryManagementForm";
            Text = "Home";
            Activated += InventroyManagementForm_Activated;
            Load += InventroyHomePage_Load;
            ((System.ComponentModel.ISupportInitialize)homePartsDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)homeProductsDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox productsSearchTextbox;
        private TextBox partsSearchTextbox;
        private Button partsSearchButton;
        private Button addProductsButton;
        private Button productsSearchButton;
        private Button exitButton;
        private Button deleteProductsButton;
        private Label homePageProductsLabel;
        private Label homePagePartsLabel;
        private Button modifyProductsButton;
        private Button deletePartsButton;
        private Button modifyPartsButton;
        private DataGridView homeProductsDataGridView;
        private Button addPartsButton;
        private Label homePageNameLabel;
        private DataGridView homePartsDataGridView;
    }
}
